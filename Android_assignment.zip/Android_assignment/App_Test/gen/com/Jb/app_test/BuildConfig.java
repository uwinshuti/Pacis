/** Automatically generated file. DO NOT MODIFY */
package com.Jb.app_test;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}