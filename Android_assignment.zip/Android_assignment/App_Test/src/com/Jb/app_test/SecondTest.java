package com.Jb.app_test;

import android.app.Activity;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.View.OnClickListener;
import android.widget.Button;
import android.widget.Toast;

public class SecondTest extends Activity {
     public MediaPlayer playmusic;
	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_second_test);
		Button btnexit=(Button)findViewById(R.id.btnsecondexit);
		Button btnplay=(Button)findViewById(R.id.btnplay);
		Button btnstop=(Button)findViewById(R.id.btnstop);
		
		btnexit.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				finish();
				System.exit(0);
			}
		});
		btnplay.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Oncreate();
			}

			private void Oncreate() {
				// TODO Auto-generated method stub
				
				Toast.makeText(getApplicationContext(), "music started", Toast.LENGTH_LONG).show();
				
		    	playmusic=MediaPlayer.create(getApplicationContext(), R.raw.p);
		    	playmusic.setLooping(false);
		    	playmusic.start();
			}
		});
		btnstop.setOnClickListener(new OnClickListener() {
			
			@Override
			public void onClick(View arg0) {
				// TODO Auto-generated method stub
				Ondestroy();
			}

			private void Ondestroy() {
				// TODO Auto-generated method stub
				Toast.makeText(getApplicationContext(), "music stopped", Toast.LENGTH_LONG).show();
				playmusic.stop();
			}
		});
	}


	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.second_test, menu);
		return true;
	}

	@Override
	public boolean onOptionsItemSelected(MenuItem item) {
		// Handle action bar item clicks here. The action bar will
		// automatically handle clicks on the Home/Up button, so long
		// as you specify a parent activity in AndroidManifest.xml.
		int id = item.getItemId();
		if (id == R.id.action_settings) {
			return true;
		}
		return super.onOptionsItemSelected(item);
	}
	
}
